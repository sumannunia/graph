import logo from './logo.svg';
import './App.css';
import Graph from './Graph'
function App() {
  return (
    <div className="App">
      <Graph />
    </div>
  );
}

export default App;
